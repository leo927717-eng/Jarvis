# Feature Registry

| ID | Feature Name | Status | Tests | Version |
| :--- | :--- | :--- | :--- | :--- |
| CORE-001 | Command Router & Multilingual Parser | Integrated | Passed | 1.0.0 |
| CORE-002 | Compose Runtime Shell | Integrated | Passed | 1.0.0 |

# JARVIS ULTRA — Project Overview

## Mission
JARVIS ULTRA is a self-evolving Android application built with Kotlin, Jetpack Compose, Material 3, and Gradle Version Catalogs. It accepts natural-language engineering requests in Hindi, English, and Hinglish and transforms them into modular Android features.

## Target Platform
- **Application ID**: `com.jarvis.ultra`
- **Min SDK**: 26 (Android 8.0)
- **Target / Compile SDK**: 35 (Android 15)
- **UI Toolkit**: Jetpack Compose + Material 3
- **Language**: Kotlin 2.0.21 (JVM 17)

# Build Guide

## Prerequisites
- JDK 17+
- Android SDK Platform 35 & Build Tools
- Gradle 8.9+ (or project Gradle Wrapper)

## Build Commands
```bash
# Run static Python verification script
python3 scripts/verify_android_project.py

# Run unit tests (in Android SDK environment)
./gradlew testDebugUnitTest

# Build Debug APK (in Android SDK environment)
./gradlew assembleDebug
```

## Expected Output Path
`app/build/outputs/apk/debug/app-debug.apk`

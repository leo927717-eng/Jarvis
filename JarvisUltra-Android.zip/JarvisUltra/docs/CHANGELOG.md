# Changelog

## [1.0.0] - Initial Baseline
- Bootstrapped `com.jarvis.ultra` Android Kotlin Jetpack Compose project.
- Added `FeatureRegistry` core module and JUnit verification test suite.
- Configured Gradle Version Catalog (`gradle/libs.versions.toml`) for AGP 8.7.2 and Kotlin 2.0.21.

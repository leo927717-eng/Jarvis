package com.jarvis.ultra

import com.jarvis.ultra.core.FeatureRegistry
import com.jarvis.ultra.core.RegisteredFeature
import org.junit.Assert.assertTrue
import org.junit.Test

class FeatureRegistryTest {
    @Test
    fun bootstrapRegistersCoreModules() {
        FeatureRegistry.bootstrapCoreModules()
        assertTrue(FeatureRegistry.exists("CORE-001"))
        assertTrue(FeatureRegistry.exists("CORE-002"))
    }

    @Test
    fun registerAddsNewFeature() {
        FeatureRegistry.register(
            RegisteredFeature(id = "TEST-900", name = "Sample Module", version = "0.1.0")
        )
        assertTrue(FeatureRegistry.exists("TEST-900"))
    }
}

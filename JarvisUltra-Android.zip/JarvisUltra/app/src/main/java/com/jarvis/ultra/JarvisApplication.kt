package com.jarvis.ultra

import android.app.Application
import com.jarvis.ultra.core.FeatureRegistry

class JarvisApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        FeatureRegistry.bootstrapCoreModules()
    }
}

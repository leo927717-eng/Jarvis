package com.jarvis.ultra.core

data class RegisteredFeature(
    val id: String,
    val name: String,
    val version: String,
    val enabled: Boolean = true
)

object FeatureRegistry {
    private val modules = linkedMapOf<String, RegisteredFeature>()

    fun bootstrapCoreModules() {
        register(
            RegisteredFeature(
                id = "CORE-001",
                name = "Command Router & Multilingual Parser",
                version = "1.0.0"
            )
        )
        register(
            RegisteredFeature(
                id = "CORE-002",
                name = "Compose Runtime Shell",
                version = "1.0.0"
            )
        )
    }

    fun register(feature: RegisteredFeature) {
        modules[feature.id] = feature
    }

    fun listAll(): List<RegisteredFeature> = modules.values.toList()

    fun exists(id: String): Boolean = modules.containsKey(id)
}

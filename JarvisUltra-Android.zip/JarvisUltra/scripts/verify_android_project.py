#!/usr/bin/env python3
"""Static verifier & security scanner for the JARVIS ULTRA Android workspace."""

import json
import os
import re
import sys
import xml.etree.ElementTree as ET

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

SECRET_PATTERNS = [
    (r"AIza[0-9A-Za-z\-_]{35}", "Hardcoded Google API Key"),
    (r"sk-[0-9A-Za-z]{20,}", "Hardcoded Secret Token"),
    (r"(?i)(password|secret|api_key)\s*=\s*\"[^\"]{6,}\"", "Hardcoded Credential Assignment"),
]

DANGEROUS_PERMISSIONS = {
    "android.permission.CAMERA": "Camera capture access",
    "android.permission.RECORD_AUDIO": "Microphone audio recording",
    "android.permission.ACCESS_FINE_LOCATION": "Precise GPS location",
    "android.permission.READ_CONTACTS": "Contacts directory access",
    "android.permission.CALL_PHONE": "Direct phone call initiation",
    "android.permission.READ_EXTERNAL_STORAGE": "External storage read access",
}


def check_balanced_braces(content: str):
    stack = []
    in_string = False
    in_line_comment = False
    in_block_comment = False
    line = 1
    i = 0
    n = len(content)
    while i < n:
        ch = content[i]
        nxt = content[i + 1] if i + 1 < n else ""
        if ch == "\n":
            in_line_comment = False
            line += 1
            i += 1
            continue
        if in_line_comment:
            i += 1
            continue
        if in_block_comment:
            if ch == "*" and nxt == "/":
                in_block_comment = False
                i += 2
                continue
            i += 1
            continue
        if not in_string and ch == "/" and nxt == "/":
            in_line_comment = True
            i += 2
            continue
        if not in_string and ch == "/" and nxt == "*":
            in_block_comment = True
            i += 2
            continue
        if ch == '"' and (i == 0 or content[i - 1] != "\\"):
            in_string = not in_string
            i += 1
            continue
        if not in_string:
            if ch in "{(":
                stack.append((ch, line))
            elif ch in "})":
                if not stack:
                    return False, line, f"Unexpected closing '{ch}'"
                top, _ = stack.pop()
                if (top == "{" and ch != "}") or (top == "(" and ch != ")"):
                    return False, line, f"Mismatched '{top}' with '{ch}'"
        i += 1
    if stack:
        ch, open_line = stack[-1]
        return False, open_line, f"Unclosed '{ch}' opened at line {open_line}"
    return True, 0, ""


def main():
    errors = []
    warnings = []
    security_findings = []
    checked_files = 0
    tests_passed = 0
    tests_failed = 0

    for dirpath, dirnames, filenames in os.walk(ROOT):
        dirnames[:] = [d for d in dirnames if not d.startswith(".")]
        for fname in filenames:
            full_path = os.path.join(dirpath, fname)
            rel_path = os.path.relpath(full_path, ROOT).replace("\\", "/")
            if rel_path.startswith("docs/") or rel_path.startswith("scripts/"):
                continue

            checked_files += 1
            with open(full_path, "r", encoding="utf-8", errors="replace") as f:
                content = f.read()

            # Check XML files
            if fname.endswith(".xml"):
                try:
                    root_elem = ET.fromstring(content)
                    tests_passed += 1
                    if fname == "AndroidManifest.xml":
                        for perm in root_elem.findall("uses-permission"):
                            name = perm.attrib.get("{http://schemas.android.com/apk/res/android}name", "")
                            if name in DANGEROUS_PERMISSIONS:
                                security_findings.append({
                                    "id": f"SEC-PERM-{len(security_findings)+1}",
                                    "severity": "Medium",
                                    "file": rel_path,
                                    "line": 1,
                                    "rule": "Sensitive Android Permission",
                                    "detail": f"Declares {name} ({DANGEROUS_PERMISSIONS[name]}).",
                                    "recommendation": "Verify runtime permission rationale & user approval before release.",
                                })
                        app_node = root_elem.find("application")
                        if app_node is not None:
                            cleartext = app_node.attrib.get("{http://schemas.android.com/apk/res/android}usesCleartextTraffic", "")
                            if cleartext.lower() == "true":
                                security_findings.append({
                                    "id": f"SEC-NET-{len(security_findings)+1}",
                                    "severity": "High",
                                    "file": rel_path,
                                    "line": 1,
                                    "rule": "Cleartext HTTP Permitted",
                                    "detail": "android:usesCleartextTraffic is set to true.",
                                    "recommendation": "Remove usesCleartextTraffic or restrict via network_security_config.xml.",
                                })
                except ET.ParseError as exc:
                    tests_failed += 1
                    line_no = exc.position[0] if hasattr(exc, "position") else 1
                    errors.append({"file": rel_path, "line": line_no, "message": f"XML syntax error: {exc}"})

            # Check Kotlin / Java / Gradle files
            if fname.endswith((".kt", ".java", ".kts")):
                ok, err_line, err_msg = check_balanced_braces(content)
                if not ok:
                    tests_failed += 1
                    errors.append({"file": rel_path, "line": err_line, "message": err_msg})
                else:
                    tests_passed += 1

                if fname.endswith((".kt", ".java")) and "src/main/java/" in rel_path:
                    if not re.search(r"^\s*package\s+[a-zA-Z0-9_.]+", content, re.MULTILINE):
                        tests_failed += 1
                        errors.append({"file": rel_path, "line": 1, "message": "Missing Kotlin/Java package declaration"})

                if "TODO(" in content:
                    warnings.append({"file": rel_path, "line": 1, "message": "Contains unimplemented TODO() stub"})

            # Security pattern scan across all source & config files
            lines = content.splitlines()
            for idx, line_str in enumerate(lines, start=1):
                for pattern, label in SECRET_PATTERNS:
                    if re.search(pattern, line_str):
                        security_findings.append({
                            "id": f"SEC-KEY-{len(security_findings)+1}",
                            "severity": "High",
                            "file": rel_path,
                            "line": idx,
                            "rule": label,
                            "detail": "Potential hardcoded credential detected in source file.",
                            "recommendation": "Move secret to BuildConfig / local.properties or server proxy.",
                        })
                if "http://" in line_str and "schemas.android.com" not in line_str and "localhost" not in line_str and "127.0.0.1" not in line_str:
                    security_findings.append({
                        "id": f"SEC-HTTP-{len(security_findings)+1}",
                        "severity": "Medium",
                        "file": rel_path,
                        "line": idx,
                        "rule": "Insecure HTTP Endpoint",
                        "detail": "Found plain http:// URL reference.",
                        "recommendation": "Upgrade endpoint URL to HTTPS.",
                    })

    result = {
        "passed": len(errors) == 0,
        "checkedFiles": checked_files,
        "testsPassed": tests_passed,
        "testsFailed": tests_failed,
        "errors": errors,
        "warnings": warnings,
        "securityFindings": security_findings,
    }
    print(json.dumps(result))


if __name__ == "__main__":
    main()
